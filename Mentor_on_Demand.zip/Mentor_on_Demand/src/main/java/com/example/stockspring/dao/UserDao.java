package com.example.stockspring.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.stockspring.model.Login;
import com.example.stockspring.model.User;

public interface UserDao  extends JpaRepository<User, Integer>{
	 public User findByEmail(String email);
	 public User findByUserId(int userId);
	 
	 @Modifying(clearAutomatically = true)
	 @Query("UPDATE User SET activeStatus='blocked' WHERE userId=:id ")
	  public int  blockUser(@Param("id")int id);
}
