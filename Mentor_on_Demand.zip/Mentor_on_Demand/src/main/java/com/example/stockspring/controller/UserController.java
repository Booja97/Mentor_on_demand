package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.dao.LoginDao;
import com.example.stockspring.dao.SendProposalDao;
import com.example.stockspring.dao.UserDao;
import com.example.stockspring.model.Login;
import com.example.stockspring.model.Mentor;
import com.example.stockspring.model.User;
import com.example.stockspring.model.SendProposal;
import com.example.stockspring.service.MentorService;
import com.example.stockspring.service.UserService;
@Controller
public class UserController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	MentorService mentorService;
	
	@Autowired
	LoginDao loginDao;
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	SendProposalDao sendProposalDao;
	
	@RequestMapping(path="/registerUser")
	public ModelAndView register() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("UserRegister");
		return mv;
	}
	@RequestMapping(path="/insertUser",method = RequestMethod.POST)    
	public String insertCompany(User user,HttpServletRequest request) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		  userService.insertUser(user);
		  loginDao.save(new Login(user));
	   
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return "Login";
		  
	  }
	@RequestMapping(path="/trainingSearch",method = RequestMethod.GET)    
	public ModelAndView trainingSearch(@RequestParam("search") String skill,HttpServletRequest request,ModelAndView mav) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		 
	    List<Mentor> mentor =	 mentorService.findTrainingSkill(skill);
	    mav.addObject("mentor", mentor);
		mav.setViewName("CourseSearchResult");

	  }
	  catch(Exception e)
	  {
		  mav.setViewName("Login");
		  e.printStackTrace();
	  }
		return mav;
		  
	  }
	@RequestMapping(path="/training",method = RequestMethod.GET)    
	public ModelAndView training(HttpServletRequest request,ModelAndView mav) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		 
	      List<Mentor> mentors =	 mentorService.findTraining();
	      mav.addObject("mentors", mentors);
		  mav.setViewName("TrainingList");

	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return mav;
		  
	  }
	
	@RequestMapping(path="/currentTraining",method = RequestMethod.GET)    
	public ModelAndView currentTraining(HttpServletRequest request,ModelAndView mav) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		 
	      //List<Mentor> mentors =	 mentorService.findTraining();
	    //  mav.addObject("mentors", mentors);
		  mav.setViewName("CurrentTraining");

	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return mav;
		  
	  }
	
	@RequestMapping(path="/completedTraining",method = RequestMethod.GET)    
	public ModelAndView completedTraining(HttpServletRequest request,ModelAndView mav) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		 
	      //List<Mentor> mentors =	 mentorService.findTraining();
	    //  mav.addObject("mentors", mentors);
		  mav.setViewName("CompletedTraining");

	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return mav;
		  
	  }
	@RequestMapping(path="/sendRequest/{mentorMail}/{skills}",method = RequestMethod.GET)    
	public String sendRequest(@PathVariable("mentorMail") String email,@PathVariable("skills") String skills,HttpServletRequest request) throws SQLException{
		HttpSession session = request.getSession(false);
	  try {
		  int userId = (int) session.getAttribute("userId");
		  System.out.println(userId);
		  System.out.println(skills);
		  System.out.println(email);
		  
		   User user= userDao.findByUserId(userId);
		   System.out.println(user);
		   String userMail= user.getEmail();
		   System.out.println(userMail);
		  String status="request";
		SendProposal send= new SendProposal(skills,email,userMail, status);
				sendProposalDao.save(send);
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return "redirect:/training";
		  
	  }
}
