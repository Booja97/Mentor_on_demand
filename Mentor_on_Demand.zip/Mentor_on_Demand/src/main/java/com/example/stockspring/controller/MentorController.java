package com.example.stockspring.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.dao.LoginDao;
import com.example.stockspring.model.Mentor;
import com.example.stockspring.service.MentorService;
import com.example.stockspring.model.Login;

@Controller
public class MentorController {
	@Autowired
	MentorService mentorService;
	
	@Autowired
	LoginDao loginDao;

	@RequestMapping(path="/registerMentor")
	public ModelAndView register() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("MentorRegister");
		return mv;
	}
	@RequestMapping(path="/insertMentor",method = RequestMethod.POST)    
	public  String insertMentor(Mentor mentor) throws SQLException{
	  try {
		  mentorService.insertMentor(mentor);
		 loginDao.save(new Login(mentor));
	   
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return "Login";
		  
	  }
}
