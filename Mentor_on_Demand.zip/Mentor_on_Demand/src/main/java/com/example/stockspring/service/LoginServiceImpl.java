package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.stockspring.dao.LoginDao;
import com.example.stockspring.dao.UserDao;
import com.example.stockspring.model.Login;
import com.example.stockspring.model.User;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	LoginDao loginDao;
	
	@Override
	public List<Login> getAllUserDetails() throws SQLException {
		
		return loginDao.findAll();
	}
}
