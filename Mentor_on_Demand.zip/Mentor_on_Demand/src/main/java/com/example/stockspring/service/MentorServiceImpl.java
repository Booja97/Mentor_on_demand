package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.MentorDao;
import com.example.stockspring.model.Mentor;
@Service
public class MentorServiceImpl implements MentorService{
	@Autowired
	private MentorDao mentorDao;

	
	 public Mentor insertMentor(Mentor mentor) throws SQLException{
		 return mentorDao.save(mentor);
	 }
	 
	 public List<Mentor> findTrainingSkill(String skill)throws SQLException{
		 return mentorDao.findBySkills(skill);
	 }
	 public List<Mentor> findTraining()throws SQLException{
		 return mentorDao.findAll();
	 }
	 
	 public List<Mentor> getMentor() throws SQLException{
		 return mentorDao.findAll();
	 }
}
