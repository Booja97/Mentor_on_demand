package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.dao.LoginDao;
import com.example.stockspring.model.Login;
import com.example.stockspring.model.User;
import com.example.stockspring.service.LoginService;
import com.example.stockspring.service.UserService;

@Controller
public class LoginController {
	@Autowired
	private LoginService loginService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	LoginDao loginDao;
	
	@RequestMapping(path="/")
	public ModelAndView login() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Login");
		return mv;
	}
	
	@RequestMapping(value="/login" ,method = RequestMethod.GET)
	public String getLoginDetails(Login login,HttpServletRequest request) throws SQLException {
	 
	 String  email=login.getEmail();
	 String  password=login.getPassword();
	 
	 Login logins = loginDao.findByEmail(email);
	
	 if(logins.getRole().equals("admin") && logins.getPassword().equals(password))
	 { 
	   HttpSession session = request.getSession();
	  return "Admin";
	 }
	 else if(logins.getRole().equals("user") && logins.getPassword().equals(password))
	 {
	  String emails= logins.getEmail();
	  User user = userService.getUserId(emails);
	  int userId=(int) user.getUserId();
	  
	  HttpSession session = request.getSession(); 
	  session.setAttribute("userId",userId);
	  return "redirect:/training";
	 }
	 else 
	  return "Login";
	  
	 
	 
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request)
	{
		ModelAndView mav;
		HttpSession session = request.getSession(false);
		int users = (int) session.getAttribute("userId");
		session.invalidate();

		mav=new ModelAndView("Login");
		return mav;
	}


	
	/*@RequestMapping(path="/login", method = RequestMethod.GET)
    public ModelAndView logincheck(Login login) throws SQLException
    {
           ModelAndView mav = null;
           List<Login> user = loginService.getAllUserDetails();
           int flag = 0;
           
           for(Login loginform:user)
           {
        	   System.out.println("login"+loginform);
           if(login.getEmail().equals(loginform.getEmail()) && login.getPassword().equals(loginform.getPassword()))
           {
                System.out.println("gbfc");
               if(loginform.getRole().equals("user"))
               {
            	   System.out.println("bvcch");
                      if(loginform.getRole().equals("blocked"))
                             mav = new ModelAndView("Login", "message", "Your account is blocked");
                      else
                             mav = new ModelAndView("User");
               }
               else if(login.getRole().equals("mentor"))
               {
                      if(loginform.getRole().equals("blocked"))
                             mav = new ModelAndView("Login", "message", "Your account is blocked");
                      else
                             mav = new ModelAndView("User");
               }
               else
               {
                      mav = new ModelAndView("user");
               }
               flag = 1;
           }
           if( flag == 0 )
               mav = new ModelAndView("Login", "message", "Invalid UserName and Password");
    }
           return mav;
    }
	@RequestMapping(path="/checkRole", method = RequestMethod.GET)
    public ModelAndView logincheck(LoginForm loginForm) throws SQLException
    {
           ModelAndView mav = null;
           
           List<Login> user = loginService.getAllUserDetails();
           
           int flag = 0;
           
           for(Login login:user)
           {
                  if(loginForm.getEmail().equals(login.getEmail()) && loginForm.getPassword().equals(login.getPassword()))
                  {
                        if(login.getRole().equals("user"))
                        {
                               if(login.getStatus().equals("blocked"))
                                      mav = new ModelAndView("Login", "message", "Your account is blocked");
                               else
                                      mav = new ModelAndView("User");
                        }
                        else if(login.getRole().equals("mentor"))
                        {
                               if(login.getStatus().equals("blocked"))
                                      mav = new ModelAndView("Login", "message", "Your account is blocked");
                               else
                                      mav = new ModelAndView("User");
                        }
                        else
                        {
                               mav = new ModelAndView("user");
                        }
                        flag = 1;
                  }
           }
           if( flag == 0 )
                  mav = new ModelAndView("Login", "message", "Invalid UserName and Password");
           return mav;
    }*/


}
