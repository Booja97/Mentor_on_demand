package com.example.stockspring.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.dao.UserDao;
import com.example.stockspring.model.Login;
import com.example.stockspring.model.Skill;
import com.example.stockspring.model.User;
import com.example.stockspring.service.AdminService;
import com.example.stockspring.service.MentorService;
import com.example.stockspring.service.UserService;

@Controller
public class AdminController {
	@Autowired
	AdminService adminService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	MentorService mentorService;
	
	@Autowired
	UserDao userDao;
	
	@RequestMapping(path="/admin")
	public ModelAndView register() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Admin");
		return mv;
	}
	
	@RequestMapping(path="/addSkill")
	public ModelAndView add() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AddSkill");
		return mv;
	}
	@RequestMapping(path="/insertSkill",method = RequestMethod.POST)    
	public String insert(Skill skill) throws SQLException{
	  try {
		  adminService.insertSkill(skill);
	   
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return "Admin";
		  
	  }
	@RequestMapping(path="/blockUser")
	public ModelAndView blockUser() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.addObject("userList",userService.getUser());
		mv.setViewName("BlockUser");
		return mv;
	}
	@RequestMapping(path="/user",method = RequestMethod.GET)    
	public String updateUser(@RequestParam("uId") int id, HttpServletRequest request) throws SQLException{
	  try {
		  
		  userDao.blockUser(id);
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
		return "Admin";
		  
	  }
	@RequestMapping(path="/blockMentor")
	public ModelAndView blockMentor() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.addObject("mentorList",mentorService.getMentor());
		mv.setViewName("BlockMentor");
		return mv;
	}

}
