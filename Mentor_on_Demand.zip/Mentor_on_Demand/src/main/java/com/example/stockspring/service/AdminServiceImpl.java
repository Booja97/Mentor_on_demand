package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.SkillDao;
import com.example.stockspring.dao.UserDao;
import com.example.stockspring.model.Login;
import com.example.stockspring.model.Skill;
import com.example.stockspring.model.User;

@Service
public class AdminServiceImpl implements AdminService  {
	@Autowired
	private SkillDao skillDao;
	@Override
	public Skill insertSkill(Skill skill) throws SQLException {
		return skillDao.save(skill);
	}
	
}
